<?php
require_once '../controlador/UsuariosController.php';

if (isset($_GET['id'])) {
    // Obtener el ID del usuario desde la URL
    $usuario_id = $_GET['id'];

    $usuariosController = new UsuariosController();

    // Obtener el usuario por ID
    $usuario = $usuariosController->obtenerUsuario($usuario_id);  // Asegúrate de tener esta función

    // Verificar si el usuario existe
    if (!$usuario) {
        echo "Usuario no encontrado.";
        exit;
    }

    $plan_base = $usuario['plan_base'] ?? '';  
    $paquete = $usuario['paquete'] ?? '';  
    $duracion = $usuario['duracion'] ?? ''; 

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Recoger los datos del formulario
        $nombre = $_POST['nombre'];
        $email = $_POST['email'];
        $edad = $_POST['edad'];
        $plan_base = $_POST['plan_base'];
        $paquete = $_POST['paquete'];
        $duracion = $_POST['duracion'];

        // Calcular costo total
        $precio_plan = 0;
        $precio_paquete = 0;

        switch ($plan_base) {
            case 'Básico': $precio_plan = 9.99; break;
            case 'Estándar': $precio_plan = 13.99; break;
            case 'Premium': $precio_plan = 17.99; break;
        }

        switch ($paquete) {
            case 'Deporte': $precio_paquete = 6.99; break;
            case 'Cine': $precio_paquete = 7.99; break;
            case 'Infantil': $precio_paquete = 4.99; break;
        }

        $costoTotal = $precio_plan + $precio_paquete;

        // Llamar al controlador para actualizar el usuario
        $usuariosController->editarUsuario($usuario_id, $nombre, $email, $edad, $plan_base, $paquete, $duracion, $costoTotal);

        // Redirigir después de la actualización

        header("Location: listar_usuario.php");
        exit; // Asegúrate de llamar a exit después de la redirección
    }
} else {
    // Redirigir si el ID no está presente en la URL
    header("Location: listar_usuarios.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Usuario</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body>
    <h1>Actualizar Usuario</h1>
    <form method="POST" onsubmit="return validateForm()">
        <label for="nombre">Nombre y Apellidos:</label>
        <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($usuario['nombre']); ?>" required>

        <label for="email">Correo Electrónico:</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($usuario['email']); ?>" required>

        <label for="edad">Edad:</label>
        <input type="number" id="edad" name="edad" value="<?php echo htmlspecialchars($usuario['edad']); ?>" required>

        <label for="plan_base">Tipo de Plan Base:</label>
        <select id="plan_base" name="plan_base" required>
             <option value="Básico" <?php if ($plan_base === 'Básico') echo 'selected'; ?>>Básico</option>
             <option value="Estándar" <?php if ($plan_base === 'Estándar') echo 'selected'; ?>>Estándar</option>
            <option value="Premium" <?php if ($plan_base === 'Premium') echo 'selected'; ?>>Premium</option>
        </select>

    <label for="paquete">Paquete Adicional:</label>
    <select id="paquete" name="paquete" required>
        <option value="Deporte" <?php if ($paquete === 'Deporte') echo 'selected'; ?>>Deporte</option>
        <option value="Cine" <?php if ($paquete === 'Cine') echo 'selected'; ?>>Cine</option>
        <option value="Infantil" <?php if ($paquete === 'Infantil') echo 'selected'; ?>>Infantil</option>
    </select>

    <label for="duracion">Duración:</label>
        <select id="duracion" name="duracion" required>
        <option value="Mensual" <?php if ($duracion === 'Mensual') echo 'selected'; ?>>Mensual</option>
        <option value="Anual" <?php if ($duracion === 'Anual') echo 'selected'; ?>>Anual</option>
    </select>

        <button type="submit">Actualizar Usuario</button>
    </form>

    <script src="../js/script.js"></script>
</body>
</html>




