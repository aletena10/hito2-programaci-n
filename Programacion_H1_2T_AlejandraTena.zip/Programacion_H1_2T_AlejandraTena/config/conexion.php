<?php
class Conexion {
    private $host = 'localhost';
    private $usuario = 'root'; 
    private $contrasena = 'curso'; 
    private $base_de_datos = 'streamweb'; 

    public $conexion;

    public function __construct() {
        $this->conexion = $this->obtenerConexion();
    }

    public function obtenerConexion() {
        // Intentamos conectar a la base de datos
        $this->conexion = new mysqli($this->host, $this->usuario, $this->contrasena, $this->base_de_datos);

        // Verificamos si hubo un error en la conexión
        if ($this->conexion->connect_error) {
            die("Conexión fallida: " . $this->conexion->connect_error);
        }

        return $this->conexion;
    }
}
?>





