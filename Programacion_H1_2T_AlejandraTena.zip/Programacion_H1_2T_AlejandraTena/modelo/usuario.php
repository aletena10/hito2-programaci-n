<?php
require_once '../controlador/UsuariosController.php';
$usuariosController = new UsuariosController();

$mensaje = '';  // Variable para almacenar el mensaje de resultado

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recoger los datos del formulario
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $edad = $_POST['edad'];
    $plan_base = $_POST['plan_base'];
    $paquete = $_POST['paquete'];
    $duracion = $_POST['duracion'];

    // Validaciones básicas
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $mensaje = 'El correo electrónico no es válido.';
    } elseif ($edad < 18 && $paquete != 'Infantil') {
        $mensaje = 'Los usuarios menores de 18 años solo pueden contratar el paquete Infantil.';
    } elseif ($plan_base == 'Básico' && !isset($paquete)) {
        $mensaje = 'El Plan Básico solo permite un paquete adicional.';
    } elseif ($paquete == 'Deporte' && $duracion == 'Mensual') {
        $mensaje = 'El paquete Deporte solo puede ser contratado con una suscripción anual.';
    } else {
        // Calcular el costo total
        $precio_plan = 0;
        $precio_paquete = 0;

        switch ($plan_base) {
            case 'Básico': $precio_plan = 9.99; break;
            case 'Estándar': $precio_plan = 13.99; break;
            case 'Premium': $precio_plan = 17.99; break;
        }

        switch ($paquete) {
            case 'Deporte': $precio_paquete = 6.99; break;
            case 'Cine': $precio_paquete = 7.99; break;
            case 'Infantil': $precio_paquete = 4.99; break;
        }

        // Ajustar el costo si la suscripción es anual
        if ($duracion == 'Anual') {
            $costoTotal = ($precio_plan + $precio_paquete) * 12; // Multiplicamos por 12 si es anual
        } else {
            $costoTotal = $precio_plan + $precio_paquete; // Mensual
        }

        // Llamar al controlador para crear o actualizar el usuario
        if (isset($_GET['id'])) {
            $resultado = $usuariosController->editarUsuario($_GET['id'], $nombre, $email, $edad, $plan_base, $paquete, $duracion, $costoTotal);
            $mensaje = $resultado;
        } else {
            $resultado = $usuariosController->agregarUsuario($nombre, $email, $edad, $plan_base, $paquete, $duracion, $costoTotal);
            $mensaje = $resultado;
        }
    }
}
?>

<!-- Aquí empieza el código HTML para mostrar el formulario de usuario -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alta/Editar Usuario</title>
</head>
<body>
    <h1><?php echo isset($_GET['id']) ? 'Actualizar' : 'Agregar'; ?> Usuario</h1>

    <?php if ($mensaje): ?>
        <p style="color: red;"><?php echo $mensaje; ?></p>
    <?php endif; ?>

    <form method="POST" action="">
        <label for="nombre">Nombre y Apellidos:</label>
        <input type="text" name="nombre" id="nombre" required value="<?php echo isset($_GET['id']) ? $usuario['nombre'] : ''; ?>"><br><br>

        <label for="email">Correo Electrónico:</label>
        <input type="email" name="email" id="email" required value="<?php echo isset($_GET['id']) ? $usuario['email'] : ''; ?>"><br><br>

        <label for="edad">Edad:</label>
        <input type="number" name="edad" id="edad" required value="<?php echo isset($_GET['id']) ? $usuario['edad'] : ''; ?>"><br><br>

        <label for="plan_base">Plan Base:</label>
        <select name="plan_base" id="plan_base" required>
            <option value="Básico" <?php echo isset($_GET['id']) && $usuario['plan_base'] == 'Básico' ? 'selected' : ''; ?>>Básico</option>
            <option value="Estándar" <?php echo isset($_GET['id']) && $usuario['plan_base'] == 'Estándar' ? 'selected' : ''; ?>>Estándar</option>
            <option value="Premium" <?php echo isset($_GET['id']) && $usuario['plan_base'] == 'Premium' ? 'selected' : ''; ?>>Premium</option>
        </select><br><br>

        <label for="paquete">Paquetes Adicionales:</label>
        <select id="paquete" name="paquete[]" multiple required>
            <option value="Deporte" <?php echo in_array('Deporte', $paquete) ? 'selected' : ''; ?>>Deporte</option>
            <option value="Cine" <?php echo in_array('Cine', $paquete) ? 'selected' : ''; ?>>Cine</option>
        <option value="Infantil" <?php echo in_array('Infantil', $paquete) ? 'selected' : ''; ?>>Infantil</option>
</select>


        <label for="duracion">Duración:</label>
        <select name="duracion" id="duracion" required>
            <option value="Mensual" <?php echo isset($_GET['id']) && $usuario['duracion'] == 'Mensual' ? 'selected' : ''; ?>>Mensual</option>
            <option value="Anual" <?php echo isset($_GET['id']) && $usuario['duracion'] == 'Anual' ? 'selected' : ''; ?>>Anual</option>
        </select><br><br>

        <button type="submit">Guardar</button>
    </form>
</body>
</html>
