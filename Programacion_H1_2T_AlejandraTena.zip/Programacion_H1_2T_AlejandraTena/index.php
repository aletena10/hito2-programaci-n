<?php
require_once 'controlador/UsuariosController.php';
$usuariosController = new UsuariosController();

// Obtener la lista de usuarios
$usuarios = $usuariosController->obtenerUsuarios();

header('Location: vista/listar_usuario.php');
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Usuarios</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

    <h1>Lista de Usuarios</h1>
    
    <?php if ($usuarios): ?>
        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Edad</th>
                    <th>Plan Base</th>
                    <th>Paquete</th>
                    <th>Duración</th>
                    <th>Costo Total</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usuarios as $usuario): ?>
                    <tr>
                        <td><?= $usuario['id'] ?></td>
                        <td><?= $usuario['nombre'] ?></td>
                        <td><?= $usuario['email'] ?></td>
                        <td><?= $usuario['edad'] ?></td>
                        <td><?= $usuario['plan_base'] ?></td>
                        <td><?= $usuario['paquete'] ?></td>
                        <td><?= $usuario['duracion'] ?></td>
                        <td><?= number_format($usuario['costoTotal'], 2) ?> €</td>
                        <td>
                        <a href="vista/actualizar_usuario.php?id=<?php echo $usuario['id']; ?>">Editar</a> | 
                        <a href="vista/eliminar_usuario.php?id=<?php echo $usuario['id']; ?>" onclick="return confirm('¿Seguro que deseas eliminar este usuario?')">Eliminar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No hay usuarios registrados.</p>
    <?php endif; ?>

    <a href="vista/alta_usuario.php">Agregar nuevo usuario</a>

</body>
</html>


