<?php
require_once '../controlador/UsuariosController.php';
$usuariosController = new UsuariosController();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $edad = $_POST['edad'];
    $plan_base = $_POST['plan_base'];
    $paquete = $_POST['paquete'];
    $duracion = $_POST['duracion'];

    // Validación de la edad: Si es menor de 18, solo puede elegir 'Infantil'
    if ($edad < 18 && $paquete != 'Infantil') {
        echo "Error: Los usuarios menores de 18 años solo pueden elegir el paquete Infantil.";
        exit; // Detiene la ejecución si hay error
    }

    // Validación para los usuarios del Plan Básico: Solo pueden seleccionar un paquete adicional
    if ($plan_base == 'Básico' && ($paquete != 'Infantil' && $paquete != '')) {
        echo "Error: Los usuarios con el Plan Básico solo pueden seleccionar un paquete adicional.";
        exit; // Detiene la ejecución si hay error
    }

    // Validación del paquete Deporte: Solo puede ser contratado con suscripción anual
    if ($paquete == 'Deporte' && $duracion != 'Anual') {
        echo "Error: El paquete Deporte solo puede ser contratado con una suscripción anual.";
        exit; // Detiene la ejecución si hay error
    }

    header("Location: listar_usuario.php");

    // Calcular costo total
    $precio_plan = 0;
    $precio_paquete = 0;

    switch ($plan_base) {
        case 'Básico': $precio_plan = 9.99; break;
        case 'Estándar': $precio_plan = 13.99; break;
        case 'Premium': $precio_plan = 17.99; break;
    }

    switch ($paquete) {
        case 'Deporte': $precio_paquete = 6.99; break;
        case 'Cine': $precio_paquete = 7.99; break;
        case 'Infantil': $precio_paquete = 4.99; break;
    }

    $costoTotal = $precio_plan + $precio_paquete;

    // Llamar al controlador para agregar el usuario
    echo $usuariosController->agregarUsuario($nombre, $email, $edad, $plan_base, $paquete, $duracion, $costoTotal);
}
?>

<link rel="stylesheet" href="../css/estilo.css">
<form method="POST" action="alta_usuario.php">
    <label for="nombre">Nombre:</label>
    <input type="text" name="nombre" id="nombre" required>
    
    <label for="email">Correo Electrónico:</label>
    <input type="email" name="email" id="email" required>
    
    <label for="edad">Edad:</label>
    <input type="number" name="edad" id="edad" required>
    
    <label for="plan_base">Plan Base:</label>
    <select name="plan_base" id="plan_base" required>
        <option value="Básico">Básico</option>
        <option value="Estándar">Estándar</option>
        <option value="Premium">Premium</option>
    </select>
    
    <label for="paquete">Paquete:</label>
    <select name="paquete" id="paquete" required>
        <option value="Deporte">Deporte</option>
        <option value="Cine">Cine</option>
        <option value="Infantil">Infantil</option>
    </select>
    
    <label for="duracion">Duración:</label>
    <select name="duracion" id="duracion" required>
        <option value="Mensual">Mensual</option>
        <option value="Anual">Anual</option>
    </select>

    <button type="submit">Registrar Usuario</button>
</form>

<script src="../js/script.js"></script>
