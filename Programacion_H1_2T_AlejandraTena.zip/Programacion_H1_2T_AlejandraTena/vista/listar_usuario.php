<?php
require_once '../controlador/UsuariosController.php';
$usuariosController = new UsuariosController();
$usuarios = $usuariosController->obtenerUsuarios();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Usuarios</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body>
    <h1>Lista de Usuarios</h1>
    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Email</th>
                <th>Edad</th>
                <th>Plan Base</th>
                <th>Paquete</th>
                <th>Duración</th>
                <th>Costo Total</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($usuarios as $usuario): ?>
                <tr>
                    <td><?php echo $usuario['nombre']; ?></td>
                    <td><?php echo $usuario['email']; ?></td>
                    <td><?php echo $usuario['edad']; ?></td>
                    <td><?php echo $usuario['plan_base']; ?></td>
                    <td><?php echo $usuario['paquete']; ?></td>
                    <td><?php echo $usuario['duracion']; ?></td>
                    <td><?php echo $usuario['costoTotal']; ?> €</td>
                    <td>
                        <a href="actualizar_usuario.php?id=<?php echo $usuario['id']; ?>">Modificar</a> |
                        <a href="eliminar_usuario.php?id=<?php echo $usuario['id']; ?>" onclick="return confirm('¿Seguro que quieres eliminar este usuario?')">Eliminar</a>
                    </td>
                    
                </tr>
            <?php endforeach; ?>
            <a href="alta_usuario.php">registrar usuario</a>
        </tbody>
    </table>
</body>
</html>

