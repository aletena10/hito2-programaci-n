function validateForm() {
    const edad = document.querySelector('input[name="edad"]').value;
    const plan_base = document.querySelector('select[name="plan_base"]').value;
    const paquete = document.querySelector('select[name="paquete"]').value;
    const duracion = document.querySelector('select[name="duracion"]').value;

    // Restricciones
    if (edad < 18 && paquete !== "Infantil") {
        alert("Los usuarios menores de 18 años solo pueden contratar el Pack Infantil.");
        return false;
    }
    if (plan_base === "Básico" && paquete === "Deporte") {
        alert("Los usuarios del Plan Básico no pueden seleccionar el paquete Deporte.");
        return false;
    }
    if (paquete === "Deporte" && duracion !== "Anual") {
        alert("El Pack Deporte solo puede ser contratado con una suscripción anual.");
        return false;
    }

    return true;
}
