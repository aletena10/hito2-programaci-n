<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/programacion/Programacion_H1_2T_AlejandraTena/config/conexion.php';


class UsuariosController {
    private $conexion;

    public function __construct() {
        $this->conexion = new Conexion();
    }
    //obtener usuarios a partir de su id
    public function obtenerUsuario($id){
        $query = "SELECT * FROM  usuarios WHERE id =?";
        $smt = $this->conexion->conexion->prepare($query);
        $smt->bind_param("i",$id);
        $smt->execute();
        return $smt->get_result()->fetch_assoc();
    }

    // Obtener usuarios junto con sus suscripciones
    public function obtenerUsuarios() {
        $conexion = $this->conexion->obtenerConexion();
    
        $sql = "
            SELECT u.id, u.nombre, u.email, u.edad, s.plan_base, s.paquete, s.duracion, s.costoTotal 
            FROM usuarios u
            LEFT JOIN suscripciones s ON u.id = s.usuario_id
        ";
    
        $resultado = $conexion->query($sql);
    
        if ($resultado->num_rows > 0) {
            $usuarios = [];
            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }
            return $usuarios;
        }
        return null;
    }

    // Agregar un usuario con su suscripción
    public function agregarUsuario($nombre, $email, $edad, $plan_base, $paquete, $duracion, $costoTotal) {
        // Verificar si el email ya está registrado
        $sql_verificar = "SELECT id FROM usuarios WHERE email = ?";
        $stmt = $this->conexion->conexion->prepare($sql_verificar);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            return "Error: El email ya está registrado.";
        }

        // Insertar el nuevo usuario
        $sql = "INSERT INTO usuarios (nombre, email, edad) VALUES (?, ?, ?)";
        $stmt = $this->conexion->conexion->prepare($sql);
        $stmt->bind_param("ssi", $nombre, $email, $edad);

        if ($stmt->execute()) {
            $usuario_id = $this->conexion->conexion->insert_id; // Obtener el ID del usuario recién creado

            // Insertar la suscripción del usuario
            $sql_suscripcion = "INSERT INTO suscripciones (usuario_id, plan_base, paquete, duracion, costoTotal) 
                                VALUES (?, ?, ?, ?, ?)";
            $stmt = $this->conexion->conexion->prepare($sql_suscripcion);
            $stmt->bind_param("isssd", $usuario_id, $plan_base, $paquete, $duracion, $costoTotal);
            
            if ($stmt->execute()) {
                return "Usuario y suscripción agregados correctamente.";
            } else {
                return "Error al agregar la suscripción: " . $stmt->error;
            }
        } else {
            return "Error al agregar usuario: " . $stmt->error;
        }
    }

    // Editar un usuario con su suscripción
    public function editarUsuario($id, $nombre, $email, $edad, $plan_base, $paquete, $duracion, $costoTotal) {
        // Actualizar el usuario
        $sql = "UPDATE usuarios SET nombre = ?, email = ?, edad = ? WHERE id = ?";
        $stmt = $this->conexion->conexion->prepare($sql);
        $stmt->bind_param("ssii", $nombre, $email, $edad, $id);


        if ($stmt->execute()) {
            // Actualizar la suscripción
            $sql_suscripcion = "UPDATE suscripciones SET plan_base = ?, paquete = ?, duracion = ?, costoTotal = ? WHERE usuario_id = ?";
            $stmt = $this->conexion->conexion->prepare($sql_suscripcion);
            $stmt->bind_param("sssdi", $plan_base, $paquete, $duracion, $costoTotal, $id);

            if ($stmt->execute()) {
                return "Usuario y suscripción actualizados correctamente.";
            } else {
                return "Error al actualizar la suscripción: " . $stmt->error;
            }
        } else {
            return "Error al actualizar usuario: " . $stmt->error;
        }
    }

    // Eliminar un usuario
    public function eliminarUsuario($id) {
        // Primero eliminar la suscripción
        $sql_suscripcion = "DELETE FROM suscripciones WHERE usuario_id = ?";
        $stmt = $this->conexion->conexion->prepare($sql_suscripcion);
        $stmt->bind_param("i", $id);
        $stmt->execute();

        // Eliminar el usuario
        $sql = "DELETE FROM usuarios WHERE id = ?";
        $stmt = $this->conexion->conexion->prepare($sql);
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            return "Usuario y suscripción eliminados correctamente.";
        } else {
            return "Error al eliminar usuario: " . $stmt->error;
        }
    }

    // Mostrar usuarios con sus suscripciones
    public function mostrarUsuarios() {
        $usuarios = $this->obtenerUsuarios();

        echo "<table border='1'>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Edad</th>
                    <th>Plan Base</th>
                    <th>Paquetes Adicionales</th>
                    <th>Duración</th>
                    <th>Costo Total</th>
                    <th>Acciones</th>
                </tr>";

        foreach ($usuarios as $usuario) {
            echo "<tr>
                    <td>{$usuario['id']}</td>
                    <td>{$usuario['nombre']}</td>
                    <td>{$usuario['email']}</td>
                    <td>{$usuario['edad']}</td>
                    <td>{$usuario['plan_base']}</td>
                    <td>{$usuario['paquete']}</td>
                    <td>{$usuario['duracion']}</td>
                    <td>{$usuario['costoTotal']}</td>
                    <td>
                        <a href='actualizar_usuario.php?id={$usuario['id']}'>Editar</a> |
                        <a href='eliminar_usuario.php?id={$usuario['id']}' onclick='return confirm(\"¿Seguro que quieres eliminar este usuario?\")'>Eliminar</a>
                    </td>
                </tr>";
        }

        echo "</table>";
    }
}
?>


