<?php
require_once '../controlador/UsuariosController.php';

$usuariosController = new UsuariosController();

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']); // Asegurarse de que es un número entero válido
    $usuariosController->eliminarUsuario($id);
    header("Location: listar_usuario.php"); // Asegúrate de redirigir a la lista y no al index
    exit; // Asegura que el script se detenga después de la redirección
} else {
    echo "ID de usuario no válido.";
}
?>

